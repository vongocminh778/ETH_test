﻿namespace ReaderDemo
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button24 = new System.Windows.Forms.Button();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.button17 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.button20 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.button32 = new System.Windows.Forms.Button();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.button23 = new System.Windows.Forms.Button();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader17 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader18 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader19 = new System.Windows.Forms.ColumnHeader();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.listView5 = new System.Windows.Forms.ListView();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox34.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox39.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(-2, -2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(831, 781);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.radioButton56);
            this.tabPage5.Controls.Add(this.textBox17);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.groupBox22);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.button12);
            this.tabPage5.Controls.Add(this.comboBox19);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.label44);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.label42);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Controls.Add(this.textBox38);
            this.tabPage5.Controls.Add(this.textBox37);
            this.tabPage5.Controls.Add(this.textBox36);
            this.tabPage5.Controls.Add(this.textBox35);
            this.tabPage5.Controls.Add(this.listView4);
            this.tabPage5.Controls.Add(this.button27);
            this.tabPage5.Controls.Add(this.button26);
            this.tabPage5.Controls.Add(this.radioButton43);
            this.tabPage5.Controls.Add(this.radioButton42);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(823, 756);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Connect Reader";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(222, 80);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(53, 16);
            this.radioButton56.TabIndex = 20;
            this.radioButton56.TabStop = true;
            this.radioButton56.Text = "RS485";
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(275, 343);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(52, 21);
            this.textBox17.TabIndex = 19;
            this.textBox17.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(220, 346);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 18;
            this.label18.Text = "485 Port:";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.radioButton50);
            this.groupBox22.Controls.Add(this.radioButton49);
            this.groupBox22.Location = new System.Drawing.Point(13, 380);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(289, 74);
            this.groupBox22.TabIndex = 17;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Language";
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(153, 30);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(65, 16);
            this.radioButton50.TabIndex = 1;
            this.radioButton50.TabStop = true;
            this.radioButton50.Text = "Chinese";
            this.radioButton50.UseVisualStyleBackColor = true;
            this.radioButton50.Click += new System.EventHandler(this.radioButton50_Click);
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(27, 30);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(65, 16);
            this.radioButton49.TabIndex = 0;
            this.radioButton49.TabStop = true;
            this.radioButton49.Text = "English";
            this.radioButton49.UseVisualStyleBackColor = true;
            this.radioButton49.Click += new System.EventHandler(this.radioButton49_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(511, 346);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 23);
            this.button13.TabIndex = 16;
            this.button13.Text = "Stop Scan";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(370, 346);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 23);
            this.button12.TabIndex = 15;
            this.button12.Text = "Scan Device";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // comboBox19
            // 
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6"});
            this.comboBox19.Location = new System.Drawing.Point(149, 343);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(67, 20);
            this.comboBox19.TabIndex = 14;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(10, 346);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(77, 12);
            this.label45.TabIndex = 13;
            this.label45.Text = "Serial Port:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(10, 294);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 12);
            this.label44.TabIndex = 11;
            this.label44.Text = "Port of Host:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(10, 249);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(119, 12);
            this.label43.TabIndex = 10;
            this.label43.Text = "IP Address of Host:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(10, 203);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(95, 12);
            this.label42.TabIndex = 9;
            this.label42.Text = "Port of Reader:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(10, 160);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(131, 12);
            this.label41.TabIndex = 8;
            this.label41.Text = "IP Address of Reader:";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(150, 285);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(72, 21);
            this.textBox38.TabIndex = 7;
            this.textBox38.Text = "9000";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(149, 240);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 21);
            this.textBox37.TabIndex = 6;
            this.textBox37.Text = "192.168.0.100";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(150, 194);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(70, 21);
            this.textBox36.TabIndex = 5;
            this.textBox36.Text = "9000";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(150, 151);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 21);
            this.textBox35.TabIndex = 4;
            this.textBox35.Text = "192.168.0.102";
            // 
            // listView4
            // 
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.listView4.GridLines = true;
            this.listView4.Location = new System.Drawing.Point(344, 145);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(275, 188);
            this.listView4.TabIndex = 0;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            this.listView4.SelectedIndexChanged += new System.EventHandler(this.listView4_SelectedIndexChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "NO.";
            this.columnHeader8.Width = 40;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "IP Address";
            this.columnHeader9.Width = 150;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Port";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(531, 80);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 23);
            this.button27.TabIndex = 3;
            this.button27.Text = "Disconnect";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(370, 80);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(104, 23);
            this.button26.TabIndex = 2;
            this.button26.Text = "Connect Reader";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(150, 80);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(53, 16);
            this.radioButton43.TabIndex = 1;
            this.radioButton43.TabStop = true;
            this.radioButton43.Text = "RS232";
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Checked = true;
            this.radioButton42.Location = new System.Drawing.Point(70, 80);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(59, 16);
            this.radioButton42.TabIndex = 0;
            this.radioButton42.TabStop = true;
            this.radioButton42.Text = "TCP/IP";
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.checkBox5);
            this.tabPage1.Controls.Add(this.progressBar1);
            this.tabPage1.Controls.Add(this.button24);
            this.tabPage1.Controls.Add(this.groupBox43);
            this.tabPage1.Controls.Add(this.groupBox42);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(823, 756);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Set Parameters";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(320, 705);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(102, 16);
            this.checkBox5.TabIndex = 32;
            this.checkBox5.Text = "Report Output";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.Visible = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(23, 692);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(284, 29);
            this.progressBar1.TabIndex = 31;
            this.progressBar1.Visible = false;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(649, 14);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(153, 29);
            this.button24.TabIndex = 7;
            this.button24.Text = "Update Basic Parameter";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.button17);
            this.groupBox43.Controls.Add(this.button29);
            this.groupBox43.Controls.Add(this.groupBox21);
            this.groupBox43.Controls.Add(this.groupBox1);
            this.groupBox43.Controls.Add(this.groupBox44);
            this.groupBox43.Controls.Add(this.groupBox28);
            this.groupBox43.Controls.Add(this.groupBox27);
            this.groupBox43.Controls.Add(this.groupBox26);
            this.groupBox43.Controls.Add(this.groupBox25);
            this.groupBox43.Controls.Add(this.textBox33);
            this.groupBox43.Controls.Add(this.label39);
            this.groupBox43.Controls.Add(this.textBox12);
            this.groupBox43.Controls.Add(this.textBox11);
            this.groupBox43.Controls.Add(this.groupBox18);
            this.groupBox43.Controls.Add(this.textBox10);
            this.groupBox43.Controls.Add(this.label12);
            this.groupBox43.Controls.Add(this.label11);
            this.groupBox43.Controls.Add(this.label10);
            this.groupBox43.Controls.Add(this.groupBox20);
            this.groupBox43.Controls.Add(this.groupBox19);
            this.groupBox43.Controls.Add(this.groupBox52);
            this.groupBox43.Controls.Add(this.comboBox18);
            this.groupBox43.Controls.Add(this.label38);
            this.groupBox43.Controls.Add(this.groupBox49);
            this.groupBox43.Controls.Add(this.groupBox45);
            this.groupBox43.Controls.Add(this.groupBox46);
            this.groupBox43.Location = new System.Drawing.Point(3, 269);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(805, 417);
            this.groupBox43.TabIndex = 6;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Parameters for Auto Mode";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(543, 339);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(259, 30);
            this.button17.TabIndex = 43;
            this.button17.Text = "Update Auto Model Parameter";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(543, 375);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(260, 30);
            this.button29.TabIndex = 42;
            this.button29.Text = "Default Parameter";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click_1);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.button10);
            this.groupBox21.Controls.Add(this.button9);
            this.groupBox21.Controls.Add(this.textBox15);
            this.groupBox21.Controls.Add(this.label15);
            this.groupBox21.Controls.Add(this.label14);
            this.groupBox21.Controls.Add(this.textBox14);
            this.groupBox21.Controls.Add(this.textBox13);
            this.groupBox21.Controls.Add(this.label13);
            this.groupBox21.Controls.Add(this.checkBox21);
            this.groupBox21.Location = new System.Drawing.Point(191, 265);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(343, 114);
            this.groupBox21.TabIndex = 41;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "ReportFilter";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(219, 8);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 28;
            this.button10.Text = "Get Filter";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(219, 33);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 27;
            this.button9.Text = "Set Filter";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(93, 80);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(199, 21);
            this.textBox15.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 12);
            this.label15.TabIndex = 25;
            this.label15.Text = "Tag Data(HEX):";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "Length of Tag EPC(bit):";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(162, 41);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(51, 21);
            this.textBox14.TabIndex = 23;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(162, 16);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(51, 21);
            this.textBox13.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(155, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "Address of Tag EPC (bit):";
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(213, 62);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(84, 16);
            this.checkBox21.TabIndex = 20;
            this.checkBox21.Text = "Ctrl Relay";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button28);
            this.groupBox1.Controls.Add(this.textBox45);
            this.groupBox1.Location = new System.Drawing.Point(543, 265);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(263, 71);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Set Reader Time";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(175, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Set Time";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(176, 43);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 23;
            this.button28.Text = "Get Time";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(6, 22);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(159, 21);
            this.textBox45.TabIndex = 21;
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.button16);
            this.groupBox44.Controls.Add(this.button25);
            this.groupBox44.Controls.Add(this.checkBox19);
            this.groupBox44.Controls.Add(this.checkBox18);
            this.groupBox44.Location = new System.Drawing.Point(-3, 260);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(188, 118);
            this.groupBox44.TabIndex = 39;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "Set Relay";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(10, 49);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(99, 23);
            this.button16.TabIndex = 3;
            this.button16.Text = "GetRelayStat";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(10, 79);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(99, 23);
            this.button25.TabIndex = 2;
            this.button25.Text = "SetRelayStat";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(80, 20);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(60, 16);
            this.checkBox19.TabIndex = 1;
            this.checkBox19.Text = "Relay2";
            this.checkBox19.UseVisualStyleBackColor = true;
            this.checkBox19.Visible = false;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(18, 20);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(60, 16);
            this.checkBox18.TabIndex = 0;
            this.checkBox18.Text = "Relay1";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.radioButton55);
            this.groupBox28.Controls.Add(this.radioButton54);
            this.groupBox28.Controls.Add(this.radioButton53);
            this.groupBox28.Controls.Add(this.radioButton52);
            this.groupBox28.Controls.Add(this.radioButton51);
            this.groupBox28.Location = new System.Drawing.Point(6, 206);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(224, 48);
            this.groupBox28.TabIndex = 38;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Timing Interval(ms)";
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(177, 25);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(41, 16);
            this.radioButton55.TabIndex = 4;
            this.radioButton55.TabStop = true;
            this.radioButton55.Text = "100";
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(134, 26);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(35, 16);
            this.radioButton54.TabIndex = 3;
            this.radioButton54.TabStop = true;
            this.radioButton54.Text = "50";
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(94, 26);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(35, 16);
            this.radioButton53.TabIndex = 2;
            this.radioButton53.TabStop = true;
            this.radioButton53.Text = "30";
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(51, 26);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(35, 16);
            this.radioButton52.TabIndex = 1;
            this.radioButton52.TabStop = true;
            this.radioButton52.Text = "20";
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(14, 25);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(35, 16);
            this.radioButton51.TabIndex = 0;
            this.radioButton51.TabStop = true;
            this.radioButton51.Text = "10";
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.checkBox6);
            this.groupBox27.Location = new System.Drawing.Point(468, 61);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(143, 35);
            this.groupBox27.TabIndex = 37;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Alarm";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(26, 12);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(90, 16);
            this.checkBox6.TabIndex = 31;
            this.checkBox6.Text = "Check Alarm";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.checkBox7);
            this.groupBox26.Controls.Add(this.label50);
            this.groupBox26.Controls.Add(this.textBox43);
            this.groupBox26.Controls.Add(this.label51);
            this.groupBox26.Controls.Add(this.textBox44);
            this.groupBox26.Location = new System.Drawing.Point(236, 133);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(195, 120);
            this.groupBox26.TabIndex = 36;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "IP Paramters of Host";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(19, 82);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(138, 16);
            this.checkBox7.TabIndex = 32;
            this.checkBox7.Text = "Inform host whether";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(9, 31);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(71, 12);
            this.label50.TabIndex = 22;
            this.label50.Text = "IP Address:";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(86, 28);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 21);
            this.textBox43.TabIndex = 24;
            this.textBox43.Text = "textBox43";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(17, 59);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 12);
            this.label51.TabIndex = 23;
            this.label51.Text = "Port:";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(87, 55);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 21);
            this.textBox44.TabIndex = 25;
            this.textBox44.Text = "textBox44";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.radioButton48);
            this.groupBox25.Controls.Add(this.radioButton47);
            this.groupBox25.Location = new System.Drawing.Point(648, 61);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(136, 57);
            this.groupBox25.TabIndex = 35;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "groupBox25";
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(7, 34);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(95, 16);
            this.radioButton48.TabIndex = 36;
            this.radioButton48.TabStop = true;
            this.radioButton48.Text = "User defined";
            this.radioButton48.UseVisualStyleBackColor = true;
            this.radioButton48.UseWaitCursor = true;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(7, 14);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(101, 16);
            this.radioButton47.TabIndex = 35;
            this.radioButton47.TabStop = true;
            this.radioButton47.Text = "ID of the Tag";
            this.radioButton47.UseVisualStyleBackColor = true;
            this.radioButton47.UseWaitCursor = true;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(647, 32);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(74, 21);
            this.textBox33.TabIndex = 31;
            this.textBox33.Text = "textBox33";
            this.textBox33.UseWaitCursor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(645, 17);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(125, 12);
            this.label39.TabIndex = 32;
            this.label39.Text = "Start Address of ID:";
            this.label39.UseWaitCursor = true;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(577, 227);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(48, 21);
            this.textBox12.TabIndex = 28;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(554, 172);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(45, 21);
            this.textBox11.TabIndex = 27;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.radioButton23);
            this.groupBox18.Controls.Add(this.radioButton30);
            this.groupBox18.Location = new System.Drawing.Point(7, 14);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(218, 37);
            this.groupBox18.TabIndex = 20;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Auto Mode";
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Checked = true;
            this.radioButton23.Location = new System.Drawing.Point(21, 16);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(83, 16);
            this.radioButton23.TabIndex = 0;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "Continuing";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(119, 16);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(59, 16);
            this.radioButton30.TabIndex = 8;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "Trgger";
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(554, 136);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 21);
            this.textBox10.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(435, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "Diapause of Report(s):";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(442, 178);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "Number of Tags:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(442, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 12);
            this.label10.TabIndex = 23;
            this.label10.Text = "Storing Time(s):";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.radioButton26);
            this.groupBox20.Controls.Add(this.radioButton27);
            this.groupBox20.Controls.Add(this.radioButton28);
            this.groupBox20.Controls.Add(this.radioButton44);
            this.groupBox20.Controls.Add(this.radioButton45);
            this.groupBox20.Location = new System.Drawing.Point(638, 124);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(161, 130);
            this.groupBox20.TabIndex = 22;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Condition of Report";
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Checked = true;
            this.radioButton26.Location = new System.Drawing.Point(8, 15);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(83, 16);
            this.radioButton26.TabIndex = 0;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "Notify Now";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(8, 57);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(41, 16);
            this.radioButton27.TabIndex = 2;
            this.radioButton27.Text = "Add";
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(8, 35);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(101, 16);
            this.radioButton28.TabIndex = 1;
            this.radioButton28.Text = "Timing Notify";
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(8, 103);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(59, 16);
            this.radioButton44.TabIndex = 4;
            this.radioButton44.Text = "Change";
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(8, 80);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(59, 16);
            this.radioButton45.TabIndex = 3;
            this.radioButton45.Text = "Remove";
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.radioButton24);
            this.groupBox19.Controls.Add(this.radioButton25);
            this.groupBox19.Location = new System.Drawing.Point(10, 172);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(220, 33);
            this.groupBox19.TabIndex = 21;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Trigger Mode";
            this.groupBox19.UseWaitCursor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(18, 12);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(77, 16);
            this.radioButton24.TabIndex = 1;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "Low Level";
            this.radioButton24.UseVisualStyleBackColor = true;
            this.radioButton24.UseWaitCursor = true;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(124, 12);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(83, 16);
            this.radioButton25.TabIndex = 0;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "High Level";
            this.radioButton25.UseVisualStyleBackColor = true;
            this.radioButton25.UseWaitCursor = true;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.radioButton40);
            this.groupBox52.Controls.Add(this.radioButton41);
            this.groupBox52.Location = new System.Drawing.Point(236, 59);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(218, 38);
            this.groupBox52.TabIndex = 17;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Format of Output";
            this.groupBox52.UseWaitCursor = true;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(18, 16);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(53, 16);
            this.radioButton40.TabIndex = 1;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "Terse";
            this.radioButton40.UseVisualStyleBackColor = true;
            this.radioButton40.UseWaitCursor = true;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(118, 16);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(71, 16);
            this.radioButton41.TabIndex = 0;
            this.radioButton41.TabStop = true;
            this.radioButton41.Text = "Standard";
            this.radioButton41.UseVisualStyleBackColor = true;
            this.radioButton41.UseWaitCursor = true;
            // 
            // comboBox18
            // 
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms"});
            this.comboBox18.Location = new System.Drawing.Point(317, 110);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(87, 20);
            this.comboBox18.TabIndex = 16;
            this.comboBox18.Text = "comboBox18";
            this.comboBox18.UseWaitCursor = true;
            this.comboBox18.Visible = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(268, 96);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(125, 12);
            this.label38.TabIndex = 15;
            this.label38.Text = "Interval of Reading:";
            this.label38.UseWaitCursor = true;
            this.label38.Visible = false;
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.textBox30);
            this.groupBox49.Controls.Add(this.textBox31);
            this.groupBox49.Controls.Add(this.label33);
            this.groupBox49.Controls.Add(this.label34);
            this.groupBox49.Location = new System.Drawing.Point(8, 100);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(219, 68);
            this.groupBox49.TabIndex = 16;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Wiegand Port Format";
            this.groupBox49.UseWaitCursor = true;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(107, 42);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(74, 21);
            this.textBox30.TabIndex = 14;
            this.textBox30.Text = "textBox30";
            this.textBox30.UseWaitCursor = true;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(108, 16);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(74, 21);
            this.textBox31.TabIndex = 0;
            this.textBox31.Text = "textBox31";
            this.textBox31.UseWaitCursor = true;
            // 
            // label33
            // 
            this.label33.AutoEllipsis = true;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 16);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 24);
            this.label33.TabIndex = 13;
            this.label33.Text = "Pulse Width \r\n(*10us):";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label33.UseWaitCursor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 41);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(89, 24);
            this.label34.TabIndex = 13;
            this.label34.Text = "Pulse Interval\r\n(*10us):";
            this.label34.UseWaitCursor = true;
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.checkBox17);
            this.groupBox45.Controls.Add(this.checkBox16);
            this.groupBox45.Controls.Add(this.checkBox15);
            this.groupBox45.Controls.Add(this.checkBox14);
            this.groupBox45.Location = new System.Drawing.Point(9, 53);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(218, 41);
            this.groupBox45.TabIndex = 6;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Working Antenna";
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(166, 20);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(48, 16);
            this.checkBox17.TabIndex = 10;
            this.checkBox17.Text = "ANT4";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(113, 20);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(48, 16);
            this.checkBox16.TabIndex = 9;
            this.checkBox16.Text = "ANT3";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(59, 20);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(48, 16);
            this.checkBox15.TabIndex = 8;
            this.checkBox15.Text = "ANT2";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(6, 20);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(48, 16);
            this.checkBox14.TabIndex = 7;
            this.checkBox14.Text = "ANT1";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.radioButton35);
            this.groupBox46.Controls.Add(this.radioButton37);
            this.groupBox46.Controls.Add(this.radioButton34);
            this.groupBox46.Controls.Add(this.radioButton33);
            this.groupBox46.Controls.Add(this.radioButton32);
            this.groupBox46.Location = new System.Drawing.Point(236, 6);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(356, 47);
            this.groupBox46.TabIndex = 6;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Port for Output";
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Checked = true;
            this.radioButton35.Location = new System.Drawing.Point(6, 20);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(53, 16);
            this.radioButton35.TabIndex = 0;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "RS232";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(125, 20);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(59, 16);
            this.radioButton37.TabIndex = 2;
            this.radioButton37.Text = "TCP/IP";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(68, 20);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(53, 16);
            this.radioButton34.TabIndex = 1;
            this.radioButton34.Text = "RS485";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(271, 20);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(77, 16);
            this.radioButton33.TabIndex = 4;
            this.radioButton33.Text = "Wiegand34";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(192, 20);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(77, 16);
            this.radioButton32.TabIndex = 3;
            this.radioButton32.Text = "Wiegand26";
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.groupBox24);
            this.groupBox42.Controls.Add(this.label17);
            this.groupBox42.Controls.Add(this.comboBox1);
            this.groupBox42.Controls.Add(this.button8);
            this.groupBox42.Controls.Add(this.groupBox23);
            this.groupBox42.Controls.Add(this.textBox39);
            this.groupBox42.Controls.Add(this.button11);
            this.groupBox42.Controls.Add(this.checkBox20);
            this.groupBox42.Controls.Add(this.label46);
            this.groupBox42.Controls.Add(this.textBox34);
            this.groupBox42.Controls.Add(this.textBox26);
            this.groupBox42.Controls.Add(this.label26);
            this.groupBox42.Controls.Add(this.label40);
            this.groupBox42.Controls.Add(this.label25);
            this.groupBox42.Controls.Add(this.textBox25);
            this.groupBox42.Controls.Add(this.groupBox48);
            this.groupBox42.Controls.Add(this.textBox29);
            this.groupBox42.Controls.Add(this.textBox27);
            this.groupBox42.Controls.Add(this.label32);
            this.groupBox42.Controls.Add(this.groupBox40);
            this.groupBox42.Controls.Add(this.label30);
            this.groupBox42.Controls.Add(this.label29);
            this.groupBox42.Controls.Add(this.label28);
            this.groupBox42.Controls.Add(this.label27);
            this.groupBox42.Controls.Add(this.comboBox15);
            this.groupBox42.Controls.Add(this.comboBox14);
            this.groupBox42.Controls.Add(this.comboBox13);
            this.groupBox42.Location = new System.Drawing.Point(3, 6);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(809, 257);
            this.groupBox42.TabIndex = 6;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Basic Parameters";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.textBox16);
            this.groupBox24.Controls.Add(this.label16);
            this.groupBox24.Controls.Add(this.textBox42);
            this.groupBox24.Controls.Add(this.textBox41);
            this.groupBox24.Controls.Add(this.textBox40);
            this.groupBox24.Controls.Add(this.label49);
            this.groupBox24.Controls.Add(this.label48);
            this.groupBox24.Controls.Add(this.label31);
            this.groupBox24.Controls.Add(this.label47);
            this.groupBox24.Controls.Add(this.textBox28);
            this.groupBox24.Location = new System.Drawing.Point(306, 105);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(305, 143);
            this.groupBox24.TabIndex = 33;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "IP Paramters of Reader";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(184, 115);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 21);
            this.textBox16.TabIndex = 41;
            this.textBox16.Text = "textBox16";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(69, 118);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 40;
            this.label16.Text = "MAC:";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(184, 89);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 21);
            this.textBox42.TabIndex = 39;
            this.textBox42.Text = "textBox42";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(184, 62);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 21);
            this.textBox41.TabIndex = 38;
            this.textBox41.Text = "textBox41";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(184, 36);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 21);
            this.textBox40.TabIndex = 37;
            this.textBox40.Text = "textBox40";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(67, 95);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(53, 12);
            this.label49.TabIndex = 36;
            this.label49.Text = "Gateway:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(65, 65);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(35, 12);
            this.label48.TabIndex = 35;
            this.label48.Text = "mask:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(65, 17);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(71, 12);
            this.label31.TabIndex = 32;
            this.label31.Text = "IP Address:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(65, 42);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(35, 12);
            this.label47.TabIndex = 34;
            this.label47.Text = "Port:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(184, 10);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 21);
            this.textBox28.TabIndex = 33;
            this.textBox28.Text = "textBox28";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(490, 66);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(137, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "Card read duration(ms)";
            // 
            // comboBox1
            // 
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms"});
            this.comboBox1.Location = new System.Drawing.Point(490, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(87, 20);
            this.comboBox1.TabIndex = 31;
            this.comboBox1.Text = "comboBox1";
            this.comboBox1.UseWaitCursor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(682, 223);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(117, 28);
            this.button8.TabIndex = 30;
            this.button8.Text = "Stop Auto";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.checkBox13);
            this.groupBox23.Location = new System.Drawing.Point(305, 63);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(136, 36);
            this.groupBox23.TabIndex = 21;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Set Buzzer";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(6, 14);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(102, 16);
            this.checkBox13.TabIndex = 0;
            this.checkBox13.Text = "Enable Buzzer";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(540, 16);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 21);
            this.textBox39.TabIndex = 5;
            this.textBox39.Text = "textBox39";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(681, 188);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(117, 28);
            this.button11.TabIndex = 29;
            this.button11.Text = "Start Auto";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(170, 8);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(102, 16);
            this.checkBox20.TabIndex = 0;
            this.checkBox20.Text = "RS485 NetWork";
            this.checkBox20.UseVisualStyleBackColor = true;
            this.checkBox20.Visible = false;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(474, 19);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 12);
            this.label46.TabIndex = 4;
            this.label46.Text = "Reader ID:";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(209, 176);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(69, 21);
            this.textBox34.TabIndex = 20;
            this.textBox34.Text = "textBox34";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(387, 41);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(78, 21);
            this.textBox26.TabIndex = 1;
            this.textBox26.Text = "textBox26";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(304, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 12);
            this.label26.TabIndex = 3;
            this.label26.Text = "SoftVersion:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 177);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(155, 12);
            this.label40.TabIndex = 1;
            this.label40.Text = "Address of Reader(1-254):";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(303, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 2;
            this.label25.Text = "HardVersion:";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(386, 16);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(78, 21);
            this.textBox25.TabIndex = 0;
            this.textBox25.Text = "textBox25";
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.radioButton46);
            this.groupBox48.Controls.Add(this.radioButton36);
            this.groupBox48.Controls.Add(this.radioButton38);
            this.groupBox48.Controls.Add(this.radioButton39);
            this.groupBox48.Location = new System.Drawing.Point(651, 42);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(148, 125);
            this.groupBox48.TabIndex = 7;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "Which protocol to read";
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Checked = true;
            this.radioButton46.Location = new System.Drawing.Point(28, 44);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(65, 16);
            this.radioButton46.TabIndex = 4;
            this.radioButton46.TabStop = true;
            this.radioButton46.Text = "EPCC1G2";
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(28, 23);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(89, 16);
            this.radioButton36.TabIndex = 3;
            this.radioButton36.Text = "ISO18000-6B";
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Enabled = false;
            this.radioButton38.Location = new System.Drawing.Point(6, 79);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(65, 16);
            this.radioButton38.TabIndex = 1;
            this.radioButton38.Text = "EPCC1G1";
            this.radioButton38.UseVisualStyleBackColor = true;
            this.radioButton38.Visible = false;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Enabled = false;
            this.radioButton39.Location = new System.Drawing.Point(6, 97);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(53, 16);
            this.radioButton39.TabIndex = 0;
            this.radioButton39.Text = "TK900";
            this.radioButton39.UseVisualStyleBackColor = true;
            this.radioButton39.Visible = false;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(211, 201);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(67, 21);
            this.textBox29.TabIndex = 11;
            this.textBox29.Text = "textBox29";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(211, 146);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(67, 21);
            this.textBox27.TabIndex = 9;
            this.textBox27.Text = "textBox27";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(5, 204);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(203, 12);
            this.label32.TabIndex = 8;
            this.label32.Text = "Max Tags of once Reading(1～100):";
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.radioButton31);
            this.groupBox40.Controls.Add(this.radioButton29);
            this.groupBox40.Location = new System.Drawing.Point(7, 21);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(271, 39);
            this.groupBox40.TabIndex = 4;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Work Mode";
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(75, 15);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(65, 16);
            this.radioButton31.TabIndex = 9;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "Command";
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Checked = true;
            this.radioButton29.Location = new System.Drawing.Point(11, 17);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(47, 16);
            this.radioButton29.TabIndex = 7;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "Auto";
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 150);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(137, 12);
            this.label30.TabIndex = 6;
            this.label30.Text = "RF Power Output(0-30):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(5, 123);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(185, 12);
            this.label29.TabIndex = 5;
            this.label29.Text = "Max.Frequency of Carrier(MHZ):";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 98);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(185, 12);
            this.label28.TabIndex = 4;
            this.label28.Text = "Min.Frequency of Carrier(MHZ):";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 72);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(179, 12);
            this.label27.TabIndex = 3;
            this.label27.Text = "BaudRate of RS232/RS485 Port:";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(194, 120);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(86, 20);
            this.comboBox15.TabIndex = 2;
            this.comboBox15.Text = "comboBox15";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(195, 94);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(85, 20);
            this.comboBox14.TabIndex = 1;
            this.comboBox14.Text = "comboBox14";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.comboBox13.Location = new System.Drawing.Point(195, 69);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(85, 20);
            this.comboBox13.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox33);
            this.tabPage2.Controls.Add(this.groupBox31);
            this.tabPage2.Controls.Add(this.groupBox29);
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.radioButton4);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(823, 756);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "EPCC1G2_Test";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.pictureBox1);
            this.groupBox33.Controls.Add(this.button21);
            this.groupBox33.Controls.Add(this.button22);
            this.groupBox33.Controls.Add(this.textBox21);
            this.groupBox33.Controls.Add(this.label22);
            this.groupBox33.Controls.Add(this.groupBox34);
            this.groupBox33.Controls.Add(this.groupBox35);
            this.groupBox33.Location = new System.Drawing.Point(523, 461);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(228, 129);
            this.groupBox33.TabIndex = 14;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Alarm";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(91, 68);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 31);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(145, 102);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 11;
            this.button21.Text = "EasAlarm";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(8, 102);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 10;
            this.button22.Text = "Set Alarm";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(160, 68);
            this.textBox21.MaxLength = 8;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(59, 21);
            this.textBox21.TabIndex = 9;
            this.textBox21.Text = "00000000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(89, 53);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(131, 12);
            this.label22.TabIndex = 3;
            this.label22.Text = "Access Password(8HEX)";
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.radioButton57);
            this.groupBox34.Controls.Add(this.radioButton58);
            this.groupBox34.Location = new System.Drawing.Point(4, 48);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(82, 51);
            this.groupBox34.TabIndex = 2;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "Eas State";
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(5, 29);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(53, 16);
            this.radioButton57.TabIndex = 1;
            this.radioButton57.TabStop = true;
            this.radioButton57.Text = "Alarm";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Checked = true;
            this.radioButton58.Location = new System.Drawing.Point(5, 14);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(71, 16);
            this.radioButton58.TabIndex = 0;
            this.radioButton58.TabStop = true;
            this.radioButton58.Text = "No Alarm";
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.comboBox7);
            this.groupBox35.Location = new System.Drawing.Point(7, 11);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(212, 37);
            this.groupBox35.TabIndex = 1;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "Select a Tag";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(17, 12);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(182, 20);
            this.comboBox7.TabIndex = 0;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.button20);
            this.groupBox31.Controls.Add(this.textBox19);
            this.groupBox31.Controls.Add(this.textBox20);
            this.groupBox31.Controls.Add(this.label20);
            this.groupBox31.Controls.Add(this.label21);
            this.groupBox31.Controls.Add(this.groupBox32);
            this.groupBox31.Location = new System.Drawing.Point(523, 356);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(228, 103);
            this.groupBox31.TabIndex = 13;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Lock Block for User";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(169, 55);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(55, 42);
            this.button20.TabIndex = 8;
            this.button20.Text = " Set \r\nProtect";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Visible = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(106, 74);
            this.textBox19.MaxLength = 8;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(59, 21);
            this.textBox19.TabIndex = 7;
            this.textBox19.Text = "00000000";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(105, 50);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(59, 21);
            this.textBox20.TabIndex = 6;
            this.textBox20.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(5, 77);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(95, 24);
            this.label20.TabIndex = 2;
            this.label20.Text = "Access Password\r\n(8HEX):";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 51);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 24);
            this.label21.TabIndex = 1;
            this.label21.Text = "Address of Tag\r\nData(WORD):";
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.comboBox6);
            this.groupBox32.Location = new System.Drawing.Point(6, 12);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(212, 37);
            this.groupBox32.TabIndex = 0;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Select a Tag";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(17, 12);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(182, 20);
            this.comboBox6.TabIndex = 0;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.button18);
            this.groupBox29.Controls.Add(this.button19);
            this.groupBox29.Controls.Add(this.textBox18);
            this.groupBox29.Controls.Add(this.label19);
            this.groupBox29.Controls.Add(this.groupBox30);
            this.groupBox29.Location = new System.Drawing.Point(7, 564);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(504, 57);
            this.groupBox29.TabIndex = 12;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Read Protect";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(420, 18);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(82, 27);
            this.button18.TabIndex = 5;
            this.button18.Text = "UnLock Read";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(342, 18);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 27);
            this.button19.TabIndex = 4;
            this.button19.Text = "Lock Read";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(272, 20);
            this.textBox18.MaxLength = 8;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(66, 21);
            this.textBox18.TabIndex = 3;
            this.textBox18.Text = "00000000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(174, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(95, 24);
            this.label19.TabIndex = 2;
            this.label19.Text = "Access \r\nPassWord(8HEX):";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.comboBox8);
            this.groupBox30.Location = new System.Drawing.Point(7, 13);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(163, 38);
            this.groupBox30.TabIndex = 1;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Select a Tag";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(6, 12);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(145, 20);
            this.comboBox8.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button7);
            this.groupBox12.Controls.Add(this.textBox9);
            this.groupBox12.Controls.Add(this.label9);
            this.groupBox12.Controls.Add(this.groupBox17);
            this.groupBox12.Controls.Add(this.groupBox16);
            this.groupBox12.Controls.Add(this.groupBox14);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Location = new System.Drawing.Point(3, 355);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(508, 206);
            this.groupBox12.TabIndex = 8;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Set protect for reading or writing";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(317, 175);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(109, 23);
            this.button7.TabIndex = 5;
            this.button7.Text = "Set Protect";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(415, 150);
            this.textBox9.MaxLength = 8;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(74, 21);
            this.textBox9.TabIndex = 4;
            this.textBox9.Text = "00000000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(272, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "Access Password(8HEX):";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.radioButton22);
            this.groupBox17.Controls.Add(this.radioButton21);
            this.groupBox17.Controls.Add(this.radioButton20);
            this.groupBox17.Controls.Add(this.radioButton19);
            this.groupBox17.Location = new System.Drawing.Point(270, 48);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(232, 95);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Lock of EPC TID and User Bank";
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(9, 73);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(113, 16);
            this.radioButton22.TabIndex = 3;
            this.radioButton22.Text = "Never writeable";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(9, 52);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(215, 16);
            this.radioButton21.TabIndex = 2;
            this.radioButton21.Text = "Writeable from the secured state";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(9, 32);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(149, 16);
            this.radioButton20.TabIndex = 1;
            this.radioButton20.Text = "Permanently writeable";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Checked = true;
            this.radioButton19.Location = new System.Drawing.Point(9, 14);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(167, 16);
            this.radioButton19.TabIndex = 0;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Writeable from any state";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.comboBox5);
            this.groupBox16.Location = new System.Drawing.Point(282, 12);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(207, 36);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Select a Tag";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(18, 12);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(175, 20);
            this.comboBox5.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.radioButton18);
            this.groupBox14.Controls.Add(this.radioButton17);
            this.groupBox14.Controls.Add(this.radioButton16);
            this.groupBox14.Controls.Add(this.radioButton15);
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Location = new System.Drawing.Point(3, 49);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(259, 152);
            this.groupBox14.TabIndex = 1;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Lock of Password";
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(7, 123);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(191, 16);
            this.radioButton18.TabIndex = 4;
            this.radioButton18.Text = "Never readable and writeable";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(7, 94);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(191, 28);
            this.radioButton17.TabIndex = 3;
            this.radioButton17.Text = "Readable and writeable from \r\nthe secured state";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(7, 77);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(227, 16);
            this.radioButton16.TabIndex = 2;
            this.radioButton16.Text = "Permanently readable and writeable";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Checked = true;
            this.radioButton15.Location = new System.Drawing.Point(7, 58);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(245, 16);
            this.radioButton15.TabIndex = 2;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Readable and writeable from any state";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.radioButton14);
            this.groupBox15.Controls.Add(this.radioButton13);
            this.groupBox15.Location = new System.Drawing.Point(5, 13);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(247, 39);
            this.groupBox15.TabIndex = 2;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Password";
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(119, 17);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(113, 16);
            this.radioButton14.TabIndex = 2;
            this.radioButton14.Text = "Access Password";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Checked = true;
            this.radioButton13.Location = new System.Drawing.Point(10, 17);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(101, 16);
            this.radioButton13.TabIndex = 2;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Kill Password";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.radioButton12);
            this.groupBox13.Controls.Add(this.radioButton11);
            this.groupBox13.Controls.Add(this.radioButton10);
            this.groupBox13.Controls.Add(this.radioButton9);
            this.groupBox13.Location = new System.Drawing.Point(3, 13);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(237, 35);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Select Memory Bank";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(169, 13);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(47, 16);
            this.radioButton12.TabIndex = 5;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "User";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(124, 13);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(41, 16);
            this.radioButton11.TabIndex = 4;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "TID";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Location = new System.Drawing.Point(79, 13);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(41, 16);
            this.radioButton10.TabIndex = 3;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "EPC";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(6, 13);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(71, 16);
            this.radioButton9.TabIndex = 2;
            this.radioButton9.Text = "Password";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Controls.Add(this.textBox4);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Location = new System.Drawing.Point(6, 258);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(237, 96);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Kill  Tag";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(175, 56);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(49, 36);
            this.button4.TabIndex = 8;
            this.button4.Text = "Kill \r\nTag";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(107, 57);
            this.textBox4.MaxLength = 8;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 21);
            this.textBox4.TabIndex = 8;
            this.textBox4.Text = "00000000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Killer PassWord\r\n(8HEX):";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.comboBox4);
            this.groupBox10.Location = new System.Drawing.Point(6, 15);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(213, 39);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Select a Tag";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(21, 13);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(168, 20);
            this.comboBox4.TabIndex = 8;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(172, 118);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(47, 16);
            this.radioButton4.TabIndex = 6;
            this.radioButton4.Text = "User";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Location = new System.Drawing.Point(6, 86);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(237, 170);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "List Selected Tag";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(108, 142);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "List Tag ID";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(17, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Detect Tag";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 117);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(207, 21);
            this.textBox3.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(164, 80);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(55, 21);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tag Data(HEX):";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(164, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(55, 21);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Length of Tag Data(bit):";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Address of Tag Data(bit):";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton3);
            this.groupBox6.Controls.Add(this.radioButton2);
            this.groupBox6.Controls.Add(this.radioButton1);
            this.groupBox6.Location = new System.Drawing.Point(6, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(213, 42);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Select Memory Bank";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(117, 18);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(41, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "TID";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(76, 18);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(41, 16);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "EPC";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Enabled = false;
            this.radioButton1.Location = new System.Drawing.Point(3, 17);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 16);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.Text = "PassWord";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.textBox8);
            this.groupBox5.Controls.Add(this.textBox7);
            this.groupBox5.Controls.Add(this.textBox6);
            this.groupBox5.Controls.Add(this.textBox5);
            this.groupBox5.Controls.Add(this.groupBox11);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Location = new System.Drawing.Point(249, 190);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(534, 160);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Read and Write Data Block";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(427, 125);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "Write";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(363, 125);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(56, 23);
            this.button5.TabIndex = 11;
            this.button5.Text = "Read";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(120, 129);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(234, 21);
            this.textBox8.TabIndex = 10;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(171, 103);
            this.textBox7.MaxLength = 8;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(58, 21);
            this.textBox7.TabIndex = 9;
            this.textBox7.Text = "00000000";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(171, 81);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(58, 21);
            this.textBox6.TabIndex = 8;
            this.textBox6.Text = "1";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(171, 57);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(58, 21);
            this.textBox5.TabIndex = 7;
            this.textBox5.Text = "0";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.radioButton8);
            this.groupBox11.Controls.Add(this.radioButton7);
            this.groupBox11.Controls.Add(this.radioButton6);
            this.groupBox11.Controls.Add(this.radioButton5);
            this.groupBox11.Location = new System.Drawing.Point(225, 10);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(303, 42);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Select Memory Bank";
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(200, 15);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(47, 16);
            this.radioButton8.TabIndex = 3;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "User";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(145, 16);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(41, 16);
            this.radioButton7.TabIndex = 2;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "TID";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(94, 16);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(41, 16);
            this.radioButton6.TabIndex = 1;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "EPC";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(7, 17);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(71, 16);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Password";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = "Written Data(HEX):";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "Access Password(8HEX):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "Length of Tag Data(WORD):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "Address of Tag Data(WORD):";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(235, 56);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(252, 64);
            this.listBox1.TabIndex = 1;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBox3);
            this.groupBox8.Location = new System.Drawing.Point(5, 13);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(214, 41);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Select a Tag";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(19, 15);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(175, 20);
            this.comboBox3.TabIndex = 2;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.listView1);
            this.groupBox7.Location = new System.Drawing.Point(249, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(534, 184);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "List EPC of Tags";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader11,
            this.columnHeader12});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(0, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(522, 164);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "NO.";
            this.columnHeader1.Width = 35;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "ID.";
            this.columnHeader2.Width = 224;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Length";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Success";
            this.columnHeader11.Width = 70;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Times";
            this.columnHeader12.Width = 80;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Location = new System.Drawing.Point(6, 44);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(237, 42);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ReaderInterval";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms",
            "200ms",
            "500ms"});
            this.comboBox2.Location = new System.Drawing.Point(30, 15);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 20);
            this.comboBox2.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(237, 40);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Antenna for Test";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(173, 17);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 16);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "ANT4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(115, 16);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(48, 16);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "ANT3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(59, 18);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(48, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "ANT2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(6, 17);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "ANT1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox50);
            this.tabPage3.Controls.Add(this.groupBox51);
            this.tabPage3.Controls.Add(this.groupBox47);
            this.tabPage3.Controls.Add(this.groupBox41);
            this.tabPage3.Controls.Add(this.groupBox39);
            this.tabPage3.Controls.Add(this.button23);
            this.tabPage3.Controls.Add(this.groupBox38);
            this.tabPage3.Controls.Add(this.groupBox37);
            this.tabPage3.Controls.Add(this.groupBox36);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(823, 756);
            this.tabPage3.TabIndex = 6;
            this.tabPage3.Text = "ISO6B_Test";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.button33);
            this.groupBox50.Controls.Add(this.button34);
            this.groupBox50.Controls.Add(this.textBox47);
            this.groupBox50.Controls.Add(this.label52);
            this.groupBox50.Location = new System.Drawing.Point(7, 366);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(247, 100);
            this.groupBox50.TabIndex = 14;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "Write Protect";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(137, 60);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 23);
            this.button33.TabIndex = 8;
            this.button33.Text = "Check Protect";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(16, 60);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(100, 23);
            this.button34.TabIndex = 8;
            this.button34.Text = "Set Protect";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(182, 20);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(60, 21);
            this.textBox47.TabIndex = 8;
            this.textBox47.Text = "0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 23);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(179, 12);
            this.label52.TabIndex = 8;
            this.label52.Text = "Address of Tag Data(8/0-223):";
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.listBox2);
            this.groupBox51.Location = new System.Drawing.Point(267, 361);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(501, 113);
            this.groupBox51.TabIndex = 13;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Information";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(6, 16);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(489, 88);
            this.listBox2.TabIndex = 0;
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.button32);
            this.groupBox47.Controls.Add(this.textBox32);
            this.groupBox47.Controls.Add(this.textBox46);
            this.groupBox47.Controls.Add(this.label36);
            this.groupBox47.Controls.Add(this.label37);
            this.groupBox47.Controls.Add(this.radioButton59);
            this.groupBox47.Controls.Add(this.radioButton60);
            this.groupBox47.Controls.Add(this.radioButton61);
            this.groupBox47.Controls.Add(this.radioButton62);
            this.groupBox47.Location = new System.Drawing.Point(267, 215);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(501, 140);
            this.groupBox47.TabIndex = 12;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "Select Tags by Condition";
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(121, 108);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(164, 23);
            this.button32.TabIndex = 8;
            this.button32.Text = "List ID of Selected Tags";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(208, 83);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 21);
            this.textBox32.TabIndex = 7;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(208, 57);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 21);
            this.textBox46.TabIndex = 6;
            this.textBox46.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 89);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(161, 12);
            this.label36.TabIndex = 5;
            this.label36.Text = "Condition(<=8 HEX Number):";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(8, 65);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(167, 12);
            this.label37.TabIndex = 4;
            this.label37.Text = "Address of Tag Data(0-223):";
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(271, 35);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(137, 16);
            this.radioButton59.TabIndex = 3;
            this.radioButton59.TabStop = true;
            this.radioButton59.Text = "Less than Condition";
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(20, 41);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(155, 16);
            this.radioButton60.TabIndex = 2;
            this.radioButton60.TabStop = true;
            this.radioButton60.Text = "Greater than Condition";
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(271, 19);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(125, 16);
            this.radioButton61.TabIndex = 1;
            this.radioButton61.TabStop = true;
            this.radioButton61.Text = "Unequal Condition";
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Checked = true;
            this.radioButton62.Location = new System.Drawing.Point(20, 19);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(113, 16);
            this.radioButton62.TabIndex = 0;
            this.radioButton62.TabStop = true;
            this.radioButton62.Text = "Equal Condition";
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.button30);
            this.groupBox41.Controls.Add(this.button31);
            this.groupBox41.Controls.Add(this.textBox22);
            this.groupBox41.Controls.Add(this.label23);
            this.groupBox41.Controls.Add(this.textBox23);
            this.groupBox41.Controls.Add(this.label24);
            this.groupBox41.Controls.Add(this.textBox24);
            this.groupBox41.Controls.Add(this.label35);
            this.groupBox41.Location = new System.Drawing.Point(3, 215);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(250, 144);
            this.groupBox41.TabIndex = 11;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "Read and Write Data Block";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(140, 112);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 23);
            this.button30.TabIndex = 8;
            this.button30.Text = "Write";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(19, 112);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 23);
            this.button31.TabIndex = 8;
            this.button31.Text = "Read";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(19, 85);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(201, 21);
            this.textBox22.TabIndex = 8;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 71);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 12);
            this.label23.TabIndex = 8;
            this.label23.Text = "Written Data(HEX):";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(184, 46);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(60, 21);
            this.textBox23.TabIndex = 8;
            this.textBox23.Text = "1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 49);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(173, 12);
            this.label24.TabIndex = 8;
            this.label24.Text = "Length of Tag Data(1-32/16):";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(185, 20);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(59, 21);
            this.textBox24.TabIndex = 8;
            this.textBox24.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(5, 26);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(179, 12);
            this.label35.TabIndex = 8;
            this.label35.Text = "Address of Tag Data(0/8-223):";
            // 
            // groupBox39
            // 
            this.groupBox39.Controls.Add(this.comboBox12);
            this.groupBox39.Location = new System.Drawing.Point(6, 106);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(245, 49);
            this.groupBox39.TabIndex = 10;
            this.groupBox39.TabStop = false;
            this.groupBox39.Text = "Select a Tag";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(20, 20);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(169, 20);
            this.comboBox12.TabIndex = 9;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.Location = new System.Drawing.Point(70, 176);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(109, 23);
            this.button23.TabIndex = 9;
            this.button23.Text = "List Tag ID";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.comboBox9);
            this.groupBox38.Location = new System.Drawing.Point(3, 58);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(248, 42);
            this.groupBox38.TabIndex = 8;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "ReaderInterval";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms",
            "200ms",
            "500ms"});
            this.comboBox9.Location = new System.Drawing.Point(37, 16);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(102, 20);
            this.comboBox9.TabIndex = 7;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.listView2);
            this.groupBox37.Location = new System.Drawing.Point(267, 3);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(509, 196);
            this.groupBox37.TabIndex = 7;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "List ID of Tags";
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19});
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(6, 20);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(495, 166);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "NO.";
            this.columnHeader16.Width = 35;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "ID.";
            this.columnHeader17.Width = 140;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Success";
            this.columnHeader18.Width = 70;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Times";
            this.columnHeader19.Width = 80;
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.checkBox12);
            this.groupBox36.Controls.Add(this.checkBox9);
            this.groupBox36.Controls.Add(this.checkBox11);
            this.groupBox36.Controls.Add(this.checkBox10);
            this.groupBox36.Location = new System.Drawing.Point(3, 3);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(248, 49);
            this.groupBox36.TabIndex = 5;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Select Antenna for Test";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(188, 20);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(48, 16);
            this.checkBox12.TabIndex = 7;
            this.checkBox12.Text = "ANT4";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Checked = true;
            this.checkBox9.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox9.Location = new System.Drawing.Point(11, 20);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(48, 16);
            this.checkBox9.TabIndex = 5;
            this.checkBox9.Text = "ANT1";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(128, 20);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(48, 16);
            this.checkBox11.TabIndex = 6;
            this.checkBox11.Text = "ANT3";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(67, 20);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(48, 16);
            this.checkBox10.TabIndex = 5;
            this.checkBox10.Text = "ANT2";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Controls.Add(this.button14);
            this.tabPage6.Controls.Add(this.listView5);
            this.tabPage6.Location = new System.Drawing.Point(4, 21);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(823, 756);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Auto Output";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(383, 561);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(107, 27);
            this.button15.TabIndex = 2;
            this.button15.Text = "Stop";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(196, 561);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(107, 27);
            this.button14.TabIndex = 1;
            this.button14.Text = "Start";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // listView5
            // 
            this.listView5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15});
            this.listView5.GridLines = true;
            this.listView5.Location = new System.Drawing.Point(10, 13);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(789, 528);
            this.listView5.TabIndex = 0;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "NO.";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Disc";
            this.columnHeader5.Width = 140;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Last";
            this.columnHeader6.Width = 140;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Count";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Ant";
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Type";
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Tag";
            this.columnHeader15.Width = 240;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 818);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Demo V1.3";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.groupBox49.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.groupBox35.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox50.ResumeLayout(false);
            this.groupBox50.PerformLayout();
            this.groupBox51.ResumeLayout(false);
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox39.ResumeLayout(false);
            this.groupBox38.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label35;

    }
}

